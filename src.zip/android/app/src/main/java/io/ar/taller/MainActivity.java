package io.ar.taller;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
